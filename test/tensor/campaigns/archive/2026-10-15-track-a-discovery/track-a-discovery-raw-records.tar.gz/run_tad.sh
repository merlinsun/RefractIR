#!/bin/bash
set -euo pipefail
export PYTHONPATH=/root/triton-latest/python
export REFRACTIR_REVISION=47d7ceb79c4e748ba4b3916de5f9f5afa08923e7
export REFRACTIR_COMPILER_FLAGS='-std=c++20 -Iinclude -Wall -Wextra -O2 -DREFRACTIR_TENSOR_REF -DUSE_BITWUZLA -I/usr/local/include'
export REFRACTIR_WORKTREE_DIRTY='false: exported with git checkout-index from the committed tree'
export TAD=/host/track-a-discovery-20261015
cd "$TAD/refractir"
PY=/root/triton-latest/.venv/bin/python
exec "$PY" test/tensor/campaigns/run_track_a_discovery.py \
  --work "$TAD/work" \
  --output "$TAD/work/track-a-discovery-batch.json" \
  --exporter "$TAD/refractir/build/bin/tensor_graph_region_export" \
  --symiri "$TAD/refractir/symiri" \
  --symirc "$TAD/refractir/symirc" \
  --revision "$REFRACTIR_REVISION" \
  --compiler-flags "$REFRACTIR_COMPILER_FLAGS" \
  --import-root "$TAD/refractir" \
  --shards 8 --devices 8 \
  --stage-timeout 900 --run-timeout 600 \
  "$@"
